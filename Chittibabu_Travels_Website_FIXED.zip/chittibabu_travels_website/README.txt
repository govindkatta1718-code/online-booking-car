చిట్టిబాబు ట్రావెల్స్ వెబ్‌సైట్

ముఖ్యం: index.html ఒక్కటే పంపితే ఫోటోలు/వీడియో కనిపించవు. ZIPలో ఉన్న assets ఫోల్డర్‌ను అలాగే ఉంచాలి.

ఫైళ్లు:
- index.html
- assets/driver.jpg
- assets/car.jpg
- assets/demo-video.mp4

చూడటానికి:
1. ZIP ఫైల్‌ను extract చేయండి.
2. index.html ఫైల్‌ను browserలో open చేయండి.

ఆన్‌లైన్‌లో publish చేసేటప్పుడు index.htmlతో పాటు assets ఫోల్డర్‌లోని మూడు ఫైళ్లనూ upload చేయాలి. ZIP ఫైల్‌ను పూర్తిగా extract చేసి, ఫోల్డర్ నిర్మాణాన్ని మార్చకండి.
